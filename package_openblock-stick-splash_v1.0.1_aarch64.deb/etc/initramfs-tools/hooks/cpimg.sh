#!/bin/sh
PREREQ=""
prereqs()
{
     echo "$PREREQ"
}
case $1 in
prereqs)
     prereqs
     exit 0
     ;;
esac

rm -f ${DESTDIR}/etc/logo.raw
cp /etc/openblock-stick/logo.raw ${DESTDIR}/etc/logo.raw
chmod 666 ${DESTDIR}/etc/logo.raw
exit 0